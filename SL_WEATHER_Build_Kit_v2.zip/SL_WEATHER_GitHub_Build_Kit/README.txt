SL WEATHER - phone-only cloud APK build kit

You need a GitHub account. No computer or Android Studio is needed for the cloud build.

Files:
- SL_WEATHER_Android_Source.zip: Android project source
- .github/workflows/android.yml: GitHub Actions workflow to build the APK

Quick setup:
1. On GitHub, create a new repository named sl-weather-apk (public or private).
2. Add the source ZIP at the repository root using Add file > Upload files.
3. Add the workflow file at exactly .github/workflows/android.yml. The easiest way is Add file > Create new file, type .github/workflows/android.yml as the filename, and paste the contents from this kit's android.yml file.
4. Commit the files. Open the Actions tab, select Build SL WEATHER APK, choose Run workflow if needed.
5. When the run finishes successfully, open that run, scroll to Artifacts, and download SL-WEATHER-APK. Extract it and install app-debug.apk on your Android phone. Android may ask you to allow installing unknown apps for the browser/files app.

Note: This builds an unsigned debug APK for personal testing. It is not a Play Store release. The workflow is not guaranteed until it completes successfully.
